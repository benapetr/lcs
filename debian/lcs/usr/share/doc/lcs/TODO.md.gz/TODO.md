# TODO

## Core Protocol

- [x] Listen for daemon-to-daemon TCP connections.
- [x] Connect to peer daemon TCP ports.
- [x] Poll peers periodically for liveness and state sync.
- [x] Add peer hello / hello-ack with node ID, node name, node role, node instance ID, node count, and resource count.
- [x] Add state sync request / response for volatile resource epochs, owners, lease IDs, and conflict states.
- [x] Add binary encode / decode helpers for peer payload fields using network byte order.
- [x] Add optional shared secret validation to peer hello / hello-ack.
- [x] Replace one-shot peer polling with persistent peer connections for liveness and state sync.
  - [x] Track per-peer persistent socket state, direction, retry time, and reconnect backoff.
  - [x] Add deterministic duplicate-session handling: lower node index opens outbound, higher node index accepts inbound.
- [x] Reuse established persistent peer connections for lease and move RPCs instead of opening short-lived request sockets in the normal path.
- [x] Add reconnect backoff per peer instead of retrying every tick.
- [x] Convert CLI status and move payloads away from raw local structs to explicit binary encode / decode helpers.
  - [x] Convert CLI move request / response payloads to explicit binary encode / decode helpers.
  - [x] Convert CLI status response payloads to explicit binary encode / decode helpers.
- [x] Reject stale peer messages by node instance ID, resource epoch, lease ID, and sequence number.
- [x] Add a sequence number cache per peer to reject duplicate or replayed requests.

## Quorum And Leases

- [x] Track peer online state and votes seen.
- [x] Calculate quorum using `floor(voting_members / 2) + 1`.
- [x] Implement majority lease grant and renewal for each VIP.
- [x] Drop locally owned VIPs immediately when majority quorum or lease renewal is lost.
- [x] Implement lease expiry using local monotonic timers.
- [x] Implement ownership epoch advancement for automatic placement and manual moves.
- [x] Implement networked move request forwarding to the target node.
- [x] Implement epoch-based handoff where a newer majority lease causes the old owner to drop the VIP.
- [x] Add explicit old-owner release request before granting the new owner lease.
- [x] Add explicit old-owner release confirmation before target activation.
- [x] Fall back to waiting for old lease expiry when the old owner is unreachable.

## VIP Management

- [x] Add selectable VIP management backend: shell `ip addr` or native netlink.
- [x] Implement startup cleanup for managed VIPs found locally without a valid majority lease.
- [x] Implement IPv4 ARP conflict probing before activation.
- [x] Implement IPv6 Neighbor Discovery conflict probing before activation.
- [x] Implement gratuitous ARP for IPv4 after activation.
- [x] Implement unsolicited Neighbor Advertisement for IPv6 after activation.
- [x] Set conflict state when ARP / Neighbor Discovery detects the VIP elsewhere.
- [x] Block activation while a VIP is in conflict state.
- [x] Persist conflict state in volatile cluster state until admin clears it.

## CLI

- [x] Show nodes, online state, quorum vote count, VIP owner, VIP state, and epoch in `lcs status`.
- [ ] Show lease ID / lease remaining time in `lcs status`.
- [x] Show conflict details in `lcs status`.
- [x] Implement `lcs move VIP NODE` through the initial networked cluster handoff protocol.
- [x] Add a command to clear conflict state after admin inspection.
- [x] Add useful exit codes for automation.
- [x] Add `--socket` long option.

## Config

- [ ] Detect duplicate keys inside sections.
- [x] Add stronger validation for socket path length and interface names.
- [x] Decide whether cluster name is required.
- [x] Add sample 3-node config.
- [x] Document all config keys and defaults in README.

## Daemon Runtime

- [x] Add explicit daemonization mode with `--daemonize`.
- [x] Add optional pidfile support.
- [x] Add systemd unit example.
- [x] Handle SIGTERM/SIGINT by releasing local VIPs cleanly when possible.
- [x] Add periodic runtime tick for lease renewal, peer timeout, and state convergence.

## Testing

- [ ] Add parser unit tests for valid and invalid configs.
- [ ] Add protocol encode / decode tests.
- [ ] Add local CLI socket integration test.
- [ ] Automate multi-daemon localhost integration test with three configs and different ports/sockets.
- [ ] Automate quorum-loss test.
- [ ] Automate manual move test.
- [ ] Add peer restart test.
- [ ] Add stale epoch rejection test.
- [ ] Add root-only or namespace-based tests for VIP add/remove and conflict probing.
